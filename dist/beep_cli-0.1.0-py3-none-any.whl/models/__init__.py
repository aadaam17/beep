"""Models Beep package."""
