"""Utility Beep package."""
