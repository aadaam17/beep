"""Storage Beep package."""
