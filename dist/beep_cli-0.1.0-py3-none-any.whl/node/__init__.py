"""Node Beep package."""
