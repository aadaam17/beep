"""Network Beep package."""
