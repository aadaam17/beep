"""Crypto Beep package."""
