"""Core Beep package."""
