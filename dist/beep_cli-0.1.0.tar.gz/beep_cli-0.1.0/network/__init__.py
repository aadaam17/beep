"""Network Beep package."""
