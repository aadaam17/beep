"""Core Beep package."""
