"""Crypto Beep package."""
