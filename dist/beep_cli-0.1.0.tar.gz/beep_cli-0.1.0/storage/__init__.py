"""Storage Beep package."""
