"""Utility Beep package."""
