"""Models Beep package."""
