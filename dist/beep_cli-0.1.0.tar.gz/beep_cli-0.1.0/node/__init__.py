"""Node Beep package."""
